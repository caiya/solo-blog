title: CentOS 7 下如何安装 Docker
date: '2019-11-05 16:00:16'
updated: '2019-11-05 16:02:05'
tags: [Docker]
permalink: /articles/2019/11/05/1572940816445.html
---
![](https://img.hacpai.com/bing/20190427.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

CentOS 7 64 下直接使用 yum 安装 Docker 环境，步骤如下：

## 1 卸载旧版本 Docker

```
sudo yum remove docker docker-common docker-selinux docker-engine
```

## 2 使用 yum 安装

安装依赖包：

```
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
```

安装慢的话，建议设置 yum 源：

```
sudo yum-config-manager --add-repo https://mirrors.ustc.edu.cn/docker-ce/linux/centos/docker-ce.repo
```

安装最新版 Docker CE:

```
sudo yum-config-manager --enable docker-ce-edge
```

## 3 安装 Docker CE

更新 yum 软件源缓存，并安装 docker-ce：

```
sudo yum makecache fast
sudo yum install docker-ce
```

## 4 启动 Docker CE

```
sudo systemctl enable docker
sudo systemctl start docker
```

## 5 将当前用户加入 Docker 用户组

默认安装完后已经建立 docker 用户组，只需要将当前用户加入组即可：

```
 sudo usermod -aG docker $USER
```

## 6 测试安装

```
docker run hello-world
```
