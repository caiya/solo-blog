title: Dubbo 基础介绍
date: '2019-11-06 20:29:04'
updated: '2019-11-06 21:01:48'
tags: [Java, Dubbo]
permalink: /articles/2019/11/06/1573043344056.html
---
![](https://img.hacpai.com/bing/20171211.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1 什么是 RPC
首先，在介绍 Dubbo 之前，不得不提的就是 RPC（Remote Procedure Call，远程过程调用），听起来好像很玄幻，其实简单来说，RPC 是一种通信协议，又称为 RPC 协议，屏蔽了底层的通信细节，是一种通过网络向远程计算机程序请求服务的过程，而对于开发者而言，这种调用和调用本地方法没有什么区别，但实质上两者在实现上是有本质区别的。

RPC 有几大优势：
* 简单：RPC 的语义清晰而简单，可以很方便地构建分布式应用；
* 高效：RPC 可以更加高效的实现远程过程调用；
* 通用：RPC 服务可以供多个服务调用者调用，实现上来说更加通用。

在具体的传输协议上，RPC 可以采用 TCP、HTTP等方式进行。一般来说，RPC 采用客户端 & 服务端的模式，客户端就是调用方，服务端就是服务提供方。由于客户端和服务端往往部署在不同的机器上，RPC 屏蔽了底层的通信协议，使得开发者只需要关心业务功能，从而避免一大堆的网络通信相关的代码。

## 2 RPC 框架有哪些
主流的 RPC 框架有阿里巴巴的 HSF、Dubbo；Facebook 的Thrift；Google 的 gRPC 等。RPC 框架的话，国内用的多的就是两种：gRPC、Dubbo，下面我们主要介绍下 Dubbo。

## 3 Dubbo 介绍
Dubbo 是阿里巴巴早在 2011 年就开源的一款分布式服务框架，目前阿里巴巴的新一代服务框架叫做 HSF（High Speed Framework，也被称为 “好舒服”），HSF 本文就不单独介绍了，单纯 Dubbo 来说，中间有段时间，阿里巴巴一度停更，这对于早期很多使用 Dubbo 的技术团队简直就是噩耗，后来也有一些自发的群体来进行 Dubbo 的维护。不过现在，Dubbo 又被阿里巴巴重新拾起，又开始了新的维护。国内也有基于 Dubbo 二次开发的服务框架，比如当当网在 Dubbo 的基础上开源了 Dubbox等。

![](https://ossaliyunbucket2.oss-cn-beijing.aliyuncs.com/vipzhou.cn/image/2018061002.png)

如上图所示为 Dubbo 的整体架构图，Dubbo 主要提供三个方面的功能：远程接口调用、负载均衡与容错；自动服务注册与发现。使用 Dubbo 可以很方便地实现分布式服务程序，下面我们就介绍下使用 Dubbo 来构建一个简单的应用。

## 4 Dubbo 开发入门
### 4.1 环境安装
* Zookeeper：Dubbo 的服务注册和发现是基于 Zookeeper 的，所以第一步当然是安装 Zookeeper，笔者直接使用 Docker 安装，安装方法比较简单，这里就不赘述了（除了 Zookeeper 外，Dubbo 还支持服务直连，以及 Redis 注册中心、Multicast 注册中心等，这里以 Zookeeper 进行说明）
### 4.2 基于 xml 配置
#### 4.2.1 服务提供方
现在开始，我们先要有一个服务提供方，首先来看下我们的 **pom.xml 依赖**：
```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.codeshop</groupId>
    <artifactId>dubbo-provider</artifactId>
    <version>1.0-SNAPSHOT</version>

    <dependencies>
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>3.8.1</version>
            <scope>test</scope>
        </dependency>
        <!-- https://mvnrepository.com/artifact/com.alibaba/dubbo -->
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>dubbo</artifactId>
            <version>2.6.6</version>
        </dependency>
        <dependency>
            <groupId>org.apache.zookeeper</groupId>
            <artifactId>zookeeper</artifactId>
            <version>3.4.10</version>
        </dependency>
        <dependency>
            <groupId>com.101tec</groupId>
            <artifactId>zkclient</artifactId>
            <version>0.5</version>
        </dependency>
        <dependency>
            <groupId>io.netty</groupId>
            <artifactId>netty-all</artifactId>
            <version>4.1.32.Final</version>
        </dependency>
        <dependency>
            <groupId>org.apache.curator</groupId>
            <artifactId>curator-framework</artifactId>
            <version>2.8.0</version>
        </dependency>
        <dependency>
            <groupId>org.apache.curator</groupId>
            <artifactId>curator-recipes</artifactId>
            <version>2.8.0</version>
        </dependency>
    </dependencies>
</project>
```
然后我们要定义一个服务提供者接口，取名为 **ProviderService**：
```java
package com.codeshop.dubbo.provider.service;

/**
 * 服务提供者
 */
public interface ProviderService {

    String SayHello(String word);
}
```
实现类的话，比较简单，该接口我们直接返回一个字符串即可，**ProviderServiceImpl** 如下：
```java
package com.codeshop.dubbo.provider.service.impl;

import com.codeshop.dubbo.provider.service.ProviderService;

/**
 * 服务提供者实现
 */
public class ProviderServiceImpl implements ProviderService {

    public String SayHello(String word) {
        return word;
    }
}
```
Dubbo 的配置方式主要有 3 种，分别是：
* **注解配置**：使用注解配置，免去 XML 配置的繁琐，也是 Spring Boot 比较推荐的配置方式；
* **API 配置**：API 配置的话，Dubbo 提供很多类及相关的 API 方法，可以很方便地实现配置；
* **XML 配置**：XML 配置要求我们有一个 xml 配置文件，类似于 Spring 的 xml 配置。

下面我们主要介绍下 XML 配置，我们在项目的 resources 目录下新建文件夹 META-INF，然后再在该目录下新建文件夹 spring，在 spring 下新建配置文件，命名为 **provider.xml**，项目结构如下：

![](https://ossaliyunbucket2.oss-cn-beijing.aliyuncs.com/vipzhou.cn/image/%E5%BE%AE%E4%BF%A1%E6%88%AA%E5%9B%BE_20191106201110.png)

provider.xml 配置详细如下：
```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:dubbo="http://code.alibabatech.com/schema/dubbo"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://code.alibabatech.com/schema/dubbo http://code.alibabatech.com/schema/dubbo/dubbo.xsd">

    <!--当前应用名称，名称要在整个分布式架构中唯一，以及应用的一些参数配置-->
    <dubbo:application name="provider" owner="codeshop">
        <dubbo:parameter key="qos.enable" value="true"/>
        <dubbo:parameter key="qos.accept.foreign.ip" value="false"/>
        <dubbo:parameter key="qos.port" value="55555"/>
    </dubbo:application>

    <!--监控中心的配置-->
    <dubbo:monitor protocol="registry"/>

    <!--注册中心的配置信息，N/A 表示由 dubbo 自动分配地址。或者说是一种直连的方式，不通过注册中心-->
<!--    <dubbo:registry address="N/A"/>-->
    <!--register="false"可以让服务提供者开发方，只订阅服务(开发的服务可能依赖其它服务)，而不注册正在开发的服务-->
    <dubbo:registry address="zookeeper://localhost:2181" check="false" protocol="zookeeper"/>

    <!--服务发布时dubbo依赖什么协议，可以配置 dubbo、webservice、Thrift、hessian、http等协议-->
    <dubbo:protocol name="dubbo" port="20880"/>

    <!--dubbo服务发布的配置，配置要发布的服务，ref代表服务实现类的bean-->
    <dubbo:service cluster="failover" retries="2" interface="com.codeshop.dubbo.provider.service.ProviderService" ref="providerService"/>

    <!--Bean定义-->
    <bean id="providerService" class="com.codeshop.dubbo.provider.service.impl.ProviderServiceImpl"/>
</beans>
```
很简单吧，我们使用 Zookeeper 进行注册发现，所以在 dubbo:registry 配置项中填入 Zookeeper 的地址。完了之后最后一步，就是在启动类中去扫描 provider.xml 配置文件，使得 Spring 正常加载配置：
```java
package com.codeshop.dubbo.provider;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;

public class App {
    public static void main(String[] args) throws IOException {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("META-INF/spring/provider.xml");
        context.start();
        System.in.read();
    }
}
```
启动项目，查看效果吧❤️ 

![](https://ossaliyunbucket2.oss-cn-beijing.aliyuncs.com/vipzhou.cn/image/%E5%BE%AE%E4%BF%A1%E6%88%AA%E5%9B%BE_20191106201702.png)

如果启动报错提示日志没有配置的话，可以在 resources 下新建 log4j.properties 文件，配置 log4j日志输出：
```
log4j.rootLogger=info, stdout

log4j.appender.stdout=org.apache.log4j.ConsoleAppender
log4j.appender.stdout.layout=org.apache.log4j.PatternLayout
log4j.appender.stdout.layout.ConversionPattern=%d %p [%c] - %m%n

log4j.appender.logfile=org.apache.log4j.FileAppender
log4j.appender.logfile.File=target/spring.log
log4j.appender.logfile.layout=org.apache.log4j.PatternLayout
log4j.appender.logfile.layout.ConversionPattern=%d %p [%c] - %m%n
```
#### 4.2.2 服务调用方
服务调用方又称为服务消费者，调用方同样需要新建 Dubbo 配置文件，指定 Zookeeper 的配置信息等：

![](https://ossaliyunbucket2.oss-cn-beijing.aliyuncs.com/vipzhou.cn/image/%E5%BE%AE%E4%BF%A1%E6%88%AA%E5%9B%BE_20191106202150.png)

**consumer.xml** 的配置内容如下：
```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:dubbo="http://code.alibabatech.com/schema/dubbo"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://code.alibabatech.com/schema/dubbo http://code.alibabatech.com/schema/dubbo/dubbo.xsd">

    <!--应用配置-->
    <dubbo:application name="consumer" owner="codeshop"/>

    <!--注册中心-->
<!--    <dubbo:registry address="N/A"/>-->
    <dubbo:registry address="zookeeper://localhost:2181" check="false" protocol="zookeeper"/>

    <!--生成一个远程服务的调用代理-->
    <!--点对点方式-->
    <dubbo:reference cluster="failover" retries="2" id="providerService" interface="com.codeshop.dubbo.provider.service.ProviderService" url="dubbo://127.0.0.1:20880/com.codeshop.dubbo.provider.service.ProviderService"/>
</beans>
```
这里我们直接使用点对点连接方式，也就是所谓的直连服务提供者，所以在 dubbo:reference 中我们是直接使用服务提供方的服务地址进行调用，interface 为具体的服务提供方的接口，如果提示找不到的话，那就需要将服务提供方进行 maven install 到本地仓库即可，注意 **pom.xml** 需要引入服务提供方的依赖：
```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.codeshop</groupId>
    <artifactId>dubbo-consumer</artifactId>
    <version>1.0-SNAPSHOT</version>

    <dependencies>
        <dependency>
            <groupId>com.codeshop</groupId>
            <artifactId>dubbo-provider</artifactId>
            <version>1.0-SNAPSHOT</version>
        </dependency>
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>3.8.1</version>
            <scope>test</scope>
        </dependency>
        <!-- https://mvnrepository.com/artifact/com.alibaba/dubbo -->
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>dubbo</artifactId>
            <version>2.6.6</version>
        </dependency>
        <dependency>
            <groupId>org.apache.zookeeper</groupId>
            <artifactId>zookeeper</artifactId>
            <version>3.4.10</version>
        </dependency>
        <dependency>
            <groupId>com.101tec</groupId>
            <artifactId>zkclient</artifactId>
            <version>0.5</version>
        </dependency>
        <dependency>
            <groupId>io.netty</groupId>
            <artifactId>netty-all</artifactId>
            <version>4.1.32.Final</version>
        </dependency>
        <dependency>
            <groupId>org.apache.curator</groupId>
            <artifactId>curator-framework</artifactId>
            <version>2.8.0</version>
        </dependency>
        <dependency>
            <groupId>org.apache.curator</groupId>
            <artifactId>curator-recipes</artifactId>
            <version>2.8.0</version>
        </dependency>
    </dependencies>
</project>
```
最后是调用类，都比较简单，直接贴代码了：
```java
package com.codeshop.dubbo.consumer;

import com.codeshop.dubbo.provider.service.ProviderService;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;

public class App {
    public static void main(String[] args) throws IOException {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("consumer.xml");
        context.start();
        ProviderService providerService = (ProviderService) context.getBean("providerService");
        String result = providerService.SayHello("hello world!");
        System.out.println(result);
        System.in.read();
    }
}

```
启动项目，就会自动去执行 Dubbo 调用，最后控制台直接打印调用的结果信息：

![](https://ossaliyunbucket2.oss-cn-beijing.aliyuncs.com/vipzhou.cn/image/%E5%BE%AE%E4%BF%A1%E6%88%AA%E5%9B%BE_20191106202813.png)

### 4.3 基于注解配置
上面我们介绍了基于 xml 配置的 Dubbo 示例，可以看到，配置还是比较繁琐的，Spring Boot 开发时比较推荐是就是使用注解配置，Spring 提供了 @Configuration 的注解，可以直接使用，下面我们就对上面的示例进行简单的修改。

#### 4.3.1 服务提供方
首先看下使用注解配置的项目结构：

![](https://ossaliyunbucket2.oss-cn-beijing.aliyuncs.com/vipzhou.cn/image/%E5%BE%AE%E4%BF%A1%E6%88%AA%E5%9B%BE_20191106203651.png)

其中 ProviderService 接口没有任何变化，主要是 ProviderServiceImpl 实现类调整如下：

```java
package com.codeshop.dubbo.provider.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.codeshop.dubbo.provider.service.ProviderService;

/**
 * @Service 用来标识服务提供方，executes用于限制并发为10
 * connections = 10，限制客户端使用连接数最大10
 */
@Service(timeout = 5000, version = "1.0.0", executes = 10, connections = 10, retries = 2, cluster = "failover")
public class ProviderServiceImpl implements ProviderService {

    public String SayHello(String word) {
        return word;
    }
}

```
这里，我们使用 @Service 进行注解，标识这是一个 Dubbo 服务，该注解上面还可以配置一些服务属性，比如注册超时时间、服务版本号、集群策略、失败重试次数等等，服务定义好之后就是我们的注解配置了：

```java
package com.codeshop.dubbo.provider.config;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ProtocolConfig;
import com.alibaba.dubbo.config.ProviderConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableDubbo(scanBasePackages = "com.codeshop.dubbo.provider.service")
public class DubboConfiguration {

    /**
     * 服务提供者信息配置
     * @return
     */
    @Bean
    public ProviderConfig providerConfig() {
        ProviderConfig providerConfig = new ProviderConfig();
        providerConfig.setTimeout(1000);
        return providerConfig;
    }

    /**
     * 分布式应用信息配置
     * @return
     */
    @Bean
    public ApplicationConfig applicationConfig() {
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName("provider-annotation");
        return applicationConfig;
    }

    /**
     * 注册中心配置
     * @return
     */
    @Bean
    public RegistryConfig registryConfig() {
        RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setProtocol("zookeeper");
        registryConfig.setAddress("localhost");
        registryConfig.setPort(2181);
        return registryConfig;
    }

    /**
     * 使用协议配置
     * @return
     */
    @Bean
    public ProtocolConfig protocolConfig() {
        ProtocolConfig protocolConfig = new ProtocolConfig();
        protocolConfig.setName("dubbo");
        protocolConfig.setPort(20880);
        return protocolConfig;
    }
}

```
每一个注解信息其实都是一个 Bean 对象，可以类比 xml 中的配置信息，启动项目：

```java
package com.codeshop.dubbo.provider;

import com.codeshop.dubbo.provider.config.DubboConfiguration;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.io.IOException;

public class App {
    public static void main(String[] args) throws IOException {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DubboConfiguration.class);
        context.start();
        System.in.read();
    }
}

```

启动后正常输出控制台信息：

![](https://ossaliyunbucket2.oss-cn-beijing.aliyuncs.com/vipzhou.cn/image/%E5%BE%AE%E4%BF%A1%E6%88%AA%E5%9B%BE_20191106204325.png)

#### 4.3.2 服务调用方
服务提供方在指定服务时标注了服务的版本号，同样地，在服务调用方这边就需要指定版本号进行调用，否则会报错找不到具体服务。来看下服务调用方的 **ConsumerService**：

```java
package com.codeshop.dubbo.consumer.service;

import com.alibaba.dubbo.config.annotation.Reference;
import com.codeshop.dubbo.provider.service.ProviderService;
import org.springframework.stereotype.Component;

@Component
public class ConsumerService {

    @Reference(version = "1.0.0")
    private ProviderService providerService;

    public String doSayHello(String word) {
        return providerService.SayHello(word);
    }
}

```

然后是调用方的 Dubbo 配置：

```java
package com.codeshop.dubbo.consumer.config;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ConsumerConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableDubbo(scanBasePackages = "com.codeshop.dubbo.consumer.service")
@ComponentScan(value = {"com.codeshop.dubbo.consumer"})
public class ConsumerConfiguration {

    /**
     * 应用配置
     * @return
     */
    @Bean
    public ApplicationConfig applicationConfig() {
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName("consumer-annotation");
        Map<String, String> params = new HashMap<String, String>();
        params.put("qos.enable", "true");
        params.put("qos.accept.foreign.ip", "false");
        params.put("qos.port", "33333");
        applicationConfig.setParameters(params);
        return applicationConfig;
    }

    /**
     * 服务消费者配置
     * @return
     */
    @Bean
    public ConsumerConfig consumerConfig() {
        ConsumerConfig consumerConfig = new ConsumerConfig();
        consumerConfig.setTimeout(3000);
        return consumerConfig;
    }

    /**
     * 注册中心配置
     * @return
     */
    @Bean
    public RegistryConfig registryConfig() {
        RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setProtocol("zookeeper");
        registryConfig.setAddress("localhost");
        registryConfig.setPort(2181);
        return registryConfig;
    }
}

```

最后是启动项目，直接远程调用：

```java
package com.codeshop.dubbo.consumer;

import com.codeshop.dubbo.consumer.config.ConsumerConfiguration;
import com.codeshop.dubbo.consumer.service.ConsumerService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.io.IOException;

public class App {
    public static void main(String[] args) throws IOException {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ConsumerConfiguration.class);
        context.start();

        ConsumerService consumerService = context.getBean(ConsumerService.class);
        String result = consumerService.doSayHello("hello world!");
        System.out.println(result);
        System.in.read();
    }
}

```

打印输出结果：

![](https://ossaliyunbucket2.oss-cn-beijing.aliyuncs.com/vipzhou.cn/image/%E5%BE%AE%E4%BF%A1%E6%88%AA%E5%9B%BE_20191106204847.png)

可以看出，我们使用注解调用的时候没有采用点对点这种调用，而是直接使用服务接口进行 RPC 调用，屏蔽了底层的通信地址等信息，就好比调用本地 Service 一般，这就是 RPC 的好处。

## 5 Dubbo Admin
什么是 Dubbo Admin，Dubbo 服务规模很大的时候，我们需要一个服务管理后台，Dubbo Admin 就是这样的角色，它是一个开源的服务后台，Git 地址： [https://github.com/apache/incubator-dubbo-ops](https://github.com/apache/incubator-dubbo-ops)。

启动都比较简单，Spring Boot 项目直接启动，启动后看下其提供的管理后台啥样子：

![](https://ossaliyunbucket2.oss-cn-beijing.aliyuncs.com/vipzhou.cn/image/%E5%BE%AE%E4%BF%A1%E6%88%AA%E5%9B%BE_20191106205529.png)

这里，我们可以很方便地进行服务查看、启用禁用、权重调节、负载均衡策略配置等，比较方便，提供了可视化的服务治理。
