title: Java 面试大全
date: '2019-11-05 16:50:18'
updated: '2019-11-05 16:50:18'
tags: [Java, 面试]
permalink: /articles/2019/11/05/1572943817988.html
---
![](https://img.hacpai.com/bing/20190611.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1 Java 基础
### 1.1 Array、List、Map、Set

Array 和 List 转换：

```java
// toList
String[] myArray = { "Apple", "Banana", "Orange" };
List<String> myList = new ArrayList<String>(Arrays.asList(myArray));
myList.add("Guava");

// toArray
set.toArray(new String[set.size()]);
```

<a name="L62qx"></a>
### 1.2 == 和 equals

- ==在基本类型时比较的是值，引用类型时比较的是引用
- equals 底层还是使用==实现，只不过很多对象如 String 重写了 equals，重写后使用值进行比较了
- hashCode 相同，equals 不一定相同，equals 可能会重写，即使不重写两个对象也有可能寻址地址相同进而导致 hashCode 相同

<a name="PIpbh"></a>
### 1.3 HashMap

- 使用数组+单项链表的方式，jdk1.8 又引入了红黑树，当链表长度大于 8 时会自动将链表改用红黑树实现
- HashMap 不是线程安全，需要线程安全可以使用 ConcurrentHashMap
- HashMap 默认容量 16，负载因子 0.75，扩容时根据2的n次方扩容（扩容条件是 size 大于临界扩容值 = 容量_负载因子，即16_0.75）
- Hash 碰撞时使用开放寻址法或拉链法解决冲突
- 重写 equals 时一定记得重写 hashCode，特别是该对象放入 Set 或者该对象作为 Map 的 key 时
- HashMap 内部使用 Entry<K,V>[] table 数组，每个 Entry 包含：key、value、hash、nextEntry
- 单项链表中每个节点的hash值是相同的
- HashMap put(k, v) 时是如何操作的？
  - 首先判断 key 是否为空，如果 null，则调用 null 专有的插入方法
  - 计算key 的 hash
  - 根据 hash 算出其在 table 数组中的位置
  - 遍历 Entry 的单项链表，如果找到一个 Entry 的 hash 相同&key相同，则替换该 Entry 的 value，返回旧 value
  - 如果遍历 Entry 链表，没有找到直接 AddEntry 到链表最前端，返回 null
- HashMap 遍历：
```java
Map<String, String> hashMap = new HashMap<>();
hashMap.put("name1", "1");
hashMap.put("name2", "2");
hashMap.put("name3", "3");
Set<Map.Entry<String, String>> set = hashMap.entrySet();
Iterator<Map.Entry<String, String>> iterator = set.iterator();
while (iterator.hasNext()) {
    Map.Entry entry = iterator.next();
    String key = (String) entry.getKey();
    String value = (String) entry.getValue();
    System.out.println("key: " + key + " value: " + value);
}
// key: name3 value: 3
// key: name2 value: 2
// key: name1 value: 1
```

HashMap put 操作示意：<br />
![](https://cdn.nlark.com/yuque/0/2019/gif/480800/1572428047230-c283ce2d-66c4-4575-a1dc-6ad93cec2df4.gif#align=left&display=inline&height=446&originHeight=446&originWidth=260&search=&size=0&status=done&width=260)

<a name="7iABY"></a>
### 1.4 LinkedHashMap

- 内部使用数组+双向链表形式，使用双向链表实现顺序性，提供两种顺序：插入顺序（默认 false ）、访问顺序 true
- LinkedHashMap 遍历和 HashMap 遍历其实方法一样，再贴一下：
```java
Map<String, String> linkedHashMap = new LinkedHashMap<>();
linkedHashMap.put("name1", "1");
linkedHashMap.put("name2", "2");
linkedHashMap.put("name3", "3");
Set<Map.Entry<String, String>> set = linkedHashMap.entrySet();
for(Map.Entry entry: set) {
    String key = (String) entry.getKey();
    String value = (String) entry.getValue();
    System.out.println("key: " + key + " value: " + value);
}
System.out.println("--------------------------------------------");
Iterator<Map.Entry<String, String>> iterator = set.iterator();
while (iterator.hasNext()) {
    Map.Entry entry = iterator.next();
    String key = (String) entry.getKey();
    String value = (String) entry.getValue();
    System.out.println("key: " + key + " value: " + value);
}
System.out.println("--------------------------------------------");
Set<String> keys = linkedHashMap.keySet();
for(String key: keys) {
    String value = linkedHashMap.get(key);
    System.out.println("key: " + key + " value: " + value);
}
// key: name1 value: 1
// key: name2 value: 2
// key: name3 value: 3
```

<a name="YE7kc"></a>
### 1.5 HashSet

- HashSet 的底层通过 HashMap 实现的，而 HashMap 在 1.7 之前使用的是数组+链表实现，在 1.8+ 使用的数组+链表+红黑树实现
- HashSet 的底层实现和 HashMap 使用的是相同的方式，因为 Map 是无序的，因此 HashSet 也无法保证顺序。HashSet 的方法也是借助 HashMap 的方法来实现的

Set的遍历：

```java
public static void main(String[] args) {
    Set<Student> students = new TreeSet<>();
    students.add(new Student("a"));
    students.add(new Student("c"));
    students.add(new Student("b"));
    for (Student student: students) {
        System.out.println(student.getName());
    }
    Iterator<Student> iterator = students.iterator();
    while (iterator.hasNext()) {
        Student student = iterator.next();
        System.out.println(student.getName());
    }
}

class Student implements Comparable<Student>{
    private String name;

    public Student(String name) {
        this.name = name;
    }

    @Override
    public int compareTo(Student student) {
        // 返回 1是升序、返回-1是降序
        return name.compareTo(student.getName());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
```

<a name="4ixvw"></a>
### 1.6 TreeSet

- TreeSet 是线程不安全的，TreeSet 的元素必须实现 Comparable 接口，否则会报错
- TreeSet 遍历时使用 Comparable 接口中的指定比较方法进行排序
- TreeSet 和 HashSet 的不同在于 TreeSet 可以指定排序方式，HashSet 不行

<a name="ToSRi"></a>
### 1.7 ArrayList 和 LinkedList 的区别

- ArrayList 底层基于数组，数据索引比较快，插入删除比较慢，因为涉及到数组的扩容等问题
- LinkedList 底层基于双向链表，插入删除较快，因为只涉及链表的指针移动，遍历较慢
- ArrayList 和 LinkedList 都非线程安全的
- Vector 是线程安全类

<a name="mYOzM"></a>
### 1.8 List、Set如何选择

- 唯一吗？
  - 是：Set
    - 排序吗？
      - 是：TreeSet、LinkedHashSet
      - 否：HashSet
  - 否：List
    - 线程安全吗？
      - 是：Vector
      - 否：ArrayList或LinkedList
        - 增删多？
          - 是：LinkedList
          - 否：ArrayList

<a name="c9daf4ad"></a>
## 2 Dubbo

<a name="G0huz"></a>
### 2.1 Dubbo 配置方式有哪几种

- xml 配置
- api 配置
- 注解配置

<a name="U2SBC"></a>
### 2.2 Dubbo 常用标签

- <dubbo:service>：用于暴漏服务
- <dubbo:reference>：用于创建一个远程服务代理
- <dubbo:protocol>：协议配置
- <dubbo:application>：应用配置
- <dubbo:registry>：注册中心配置
- <dubbo:monitor>：监控中心配置
- <dubbo:provider>：提供者配置
- <dubbo:consumer>：消费者配置
- <dubbo:method>：方法配置
- <dubbo:argument>：参数配置

<a name="Pgpg2"></a>
### 2.3 Dubbo 配置的优先级

- 方法级优先，接口级次之，全局配置次之
- 如果级别一样，则消费者优先，提供者次之

<a name="kfDJX"></a>
### 2.4 Dubbo 支持的协议有哪些

Dubbo、Hessian、Http、RMI、Thrift、Memcache、Redis

<a name="CVd8x"></a>
## 3 多线程

<a name="uIwWq"></a>
### 3.1 可见性

线程运行时会 load 一份主内存数据到线程本地内存，对本地内存的修改不会自动同步到主内存，使用 volatile 修饰的变量在某线程修改后，会强制刷新到主内存，其它线程再读取变量时强制从主内存读取，确保读取到的数据是最新的

<a name="6JCrY"></a>
### 3.2 有序性

编译时 jvm 会进行代码重组，但是重组一定会保证语句顺序发生改变后但结果不会改变

<a name="CVLnM"></a>
### 3.3 volatile 和 synchronize、transient 的区别

- volatile 只能保证可见性和有序性，不能保证原子性
- synchronize 可以保证原子性
- transient 表示成员变量不参与序列化

<a name="oFZrZ"></a>
### 3.4 线程私有

- 程序计数器
- 虚拟机栈
- 本地方法栈

<a name="NwWJo"></a>
### 3.5 所有线程共享

- 堆
- 常量池
- 元空间 Metaspace

<a name="3v3wK"></a>
### 3.6 Executors 创建线程池

- newFixedThreadPool(int nThreads)：创建固定大小的线程池
- newSingleThreadExecutor()：创建只有一个线程的线程池
- newCachedThreadPool()：创建不限数据的线程池，任何提交的任务都将立即执行

<a name="Ks3BS"></a>
### 3.7 ThreadPoolExecutor

ThreadPoolExecutor 构造方法如下：

```java
// Java线程池的完整构造函数
public ThreadPoolExecutor(
  int corePoolSize, // 线程池长期维持的线程数，即使线程处于 Idle 状态，也不会回收。
  int maximumPoolSize, // 线程数的上限
  long keepAliveTime, TimeUnit unit, // 超过 corePoolSize 的线程的 Idle 时长，
                                     // 超过这个时间，多余的线程会被回收。
  BlockingQueue<Runnable> workQueue, // 任务的排队队列
  ThreadFactory threadFactory, // 新线程的产生方式
  RejectedExecutionHandler handler // 拒绝策略
)
```

<a name="s7fFQ"></a>
### 3.8 线程池的工作顺序

corePoolSize -> 任务队列 -> maximumPoolSize -> 拒绝策略

<a name="BpM3K"></a>
### 3.9 Runnable 和 Callable

- Runnable 返回 void、Callable 允许有返回值
- Callable 允许抛出异常

<a name="SCNlX"></a>
### 3.10 线程池的三种任务提交方式

- Future submit(Callable task)：关心结果
- void execute(Runnable command)：不关心结果
- Future<?> submit(Runnable task)：不关心结果

<a name="FgEbn"></a>
### 3.11 线程池常见的拒绝策略

- AbortPolicy：抛出 RejectedExecutionException
- DiscardPolicy：什么也不做，直接忽略
- DiscardOldestPolicy：丢弃执行队列中最老的任务，尝试为当前提交的任务腾出位置
- CallerRunsPolicy：直接由提交任务者执行这个任务

<a name="ZBiEL"></a>
### 3.12 线程的几种状态

新建、就绪、运行、阻塞、死亡

<a name="yvspI"></a>
### 3.13 线程间通信的几种方式

- 传统的通信方式，使用 Object 类的 wait、notify、notifyAll 方法：wait 会导致当前线程等待，直到有线程调用 notify
- 使用 Condition 控制线程通信：由 Lock.newCondition 创建
- 使用阻塞队列控制线程通信：程序中的线程可以交替的向阻塞队列中放入、取出元素，主要是 put、take，分别表示队列的存取

<a name="Nhg3H"></a>
### 3.14、BlockQueue 阻塞队列的几种实现类

- ArrayBlockQueue：基于数组实现
- LinkedBlockQueue：基于链表实现
- PriorityBlockQueue：优先级阻塞队列
- SynchronousQueue：同步队列，对该队列的存取必须同步进行，类似于 Golang 中的容量为 1 的 chan
- DelayQueue：延时队列

<a name="oSub3"></a>
### 3.15 线程控制

- join 线程：调用者所在线程必须等待 join 的线程
- daemon后台线程：thread.setDaemon(true) -> thread.start()，主线程结束后后台线程自动结束
- sleep线程：出让 cpu 时间片，同 yield 的区别是：yield 只是“暂停”了一下，可能线程调度器随后又将其调度执行，非真正意义的暂停
- 线程优先级：setPriority(int n)，设置线程优先级

<a name="xV1j1"></a>
### 3.16 线程死亡的几个原因

- 手动调用线程 stop 方法（容易导致死锁，不推荐）
- run 或 call 方法执行结束
- 线程中有未捕获的异常

<a name="rprZO"></a>
### 3.17、线程同步

- synchronized
- ReentrantLock

<a name="b2a8185c"></a>
## 4 队列 Queue

- 队列一般都是 FIFO（先进先出）的数据结构，但是优先级队列不是，优先级队列有两种排序方式：自然排序、定制排序，默认是自然顺序
- Queue 的操作接口通常有：
  - 插入：add、offer（队列在有限容量时性能较add好）
  - 获取：peek（获取头部元素，获取后不删除，队列为空返回 null ）、poll（获取后删除，其它同 peek）、remove（获取并删除）、element（获取不删除）

<a name="dkgbq"></a>
### 常见队列：

- PriorityQueue：优先级队列
- ArrayDeque：双端队列
- ArrayBlockQueue：基于数组实现
- LinkedBlockQueue：基于链表实现
- PriorityBlockQueue：优先级阻塞队列
- SynchronousQueue：同步队列，对该队列的存取必须同步进行，类似于Golang中的容量为1的chan
- DelayQueue：延时队列

## 5 Mybatis 面试题

<a name="o4Tpv"></a>
### 5.1 #{} 和 ${} 的区别是什么

#{} 是预编译处理，${} 是字符串替换

<a name="POXop"></a>
### 5.2 实体类中的属性名和表中的字段名不一样，怎么办

- sql 查询指定别名
- 使用 Mybatis 的 ResultMap 映射

<a name="bhfl4"></a>
### 5.3 模糊查询 like 语句该怎么写

```xml
<select id="selectlike"> 
    select * from foo where bar like "%"#{value}"%"
    select * from foo where bar like concat(concat('%',#{username}),'%')
</select>
```

<a name="A8VJu"></a>
### 5.4 Dao 接口里的方法可以重载吗

Dao 接口里的方法，是不能重载的，因为是全限名+方法名的保存和寻找策略

<a name="NoRXh"></a>
### 5.5 Dao 接口的工作原理

JDK 动态代理，Mybatis 运行时会使用 JDK 动态代理为 Dao 接口生成代理 proxy 对象（如使用 spring 会注入到容器中），代理对象 proxy 会拦截接口方法，转而执行 MappedStatement 所代表的 sql，然后将 sql 执行结果返回

<a name="zCcum"></a>
### 5.6、ResultType 和 ResultMap

- 使用 ResultType 进行输出映射，只有查询出来的列名和 POJO（实体 Bean ）中的属性名一致，该列才可以映射成功
- ResultType：可以输出 POJO、POJO 列表、HashMap 对象
- ResultMap：高级结果映射，可以指定 association、collections 进行关联查询

<a name="tq8Mi"></a>
### 5.7 在 mapper 中如何传递多个参数

- 第一种：
  
```java  
// DAO 层的函数  
Public UserselectUser(String name,String area);  
```
```xml
// 对应的 xml,#{0} 代表接收的是 dao 层中的第一个参数，#{1} 代表 dao 层中第二参数，更多参数一致往后加即可。
<select id="selectUser"resultMap="BaseResultMap">  
    select *  fromuser_user_t   whereuser_name = #{0} anduser_area=#{1}  
</select>
```

- 第二种：

```java
public interface usermapper { 
  user selectUser(@param("username") string username, @param("hashedpassword") string hashedpassword);
}
```

```xml
<select id="selectuser" resulttype="user"> 
    select id, username, hashedpassword 
    from some_table 
    where username = #{username} 
    and hashedpassword = #{hashedpassword} 
</select>
```

### 5.8 Mybatis 动态 sql 的执行原理

- Mybatis 提供了 9 种动态 sql 标签：trim|where|set|foreach|if|choose|when|otherwise|bind
- 其执行原理为，从 sql 参数对象中计算表达式的值，根据表达式的值动态拼接sql，以此来完成动态 sql 的功能

<a name="zcoZb"></a>
### 5.9 为什么说 Mybatis 是半自动 ORM 映射工具

因为 Mybatis 在查询关联对象或者关联集合对象时，需要手动编写 sql 完成，而 Hibernate 就属于全自动不用手写 sql

<a name="ltI7z"></a>
### 5.10 Mybatis 关联查询

```xml
<mapper namespace="com.lcb.mapping.userMapper">  
    <!--association  一对一关联查询 -->  
    <select id="getClass" parameterType="int" resultMap="ClassesResultMap">  
        select * from class c,teacher t where c.teacher_id=t.t_id and c.c_id=#{id}  
    </select>  
    <resultMap type="com.lcb.user.Classes" id="ClassesResultMap">  
        <!-- 实体类的字段名和数据表的字段名映射 -->  
        <id property="id" column="c_id"/>  
        <result property="name" column="c_name"/>  
        <association property="teacher" javaType="com.lcb.user.Teacher">  
            <id property="id" column="t_id"/>  
            <result property="name" column="t_name"/>  
        </association>  
    </resultMap>  

    <!--collection  一对多关联查询 -->  
    <select id="getClass2" parameterType="int" resultMap="ClassesResultMap2">  
        select * from class c,teacher t,student s where c.teacher_id=t.t_id and c.c_id=s.class_id and c.c_id=#{id}  
    </select>  
    <resultMap type="com.lcb.user.Classes" id="ClassesResultMap2">  
        <id property="id" column="c_id"/>  
        <result property="name" column="c_name"/>  
        <association property="teacher" javaType="com.lcb.user.Teacher">  
            <id property="id" column="t_id"/>  
            <result property="name" column="t_name"/>  
        </association>  
        <collection property="student" ofType="com.lcb.user.Student">  
            <id property="id" column="s_id"/>  
            <result property="name" column="s_name"/>  
        </collection>  
    </resultMap>  
</mapper>
```

<a name="0c22ad9f"></a>
## 6 Spring Ioc Aop

<a name="8i3jt"></a>
### 6.1 系统业务分类

- 核心关注点：关注系统业务核心
- 横切关注点：关注系统共有模块，比如日志管理、权限拦截、事务管理、系统监控等

<a name="KaMnZ"></a>
### 6.2 Aop 的一些概念

- 连接点（JoinPoint）：就是需要拦截的点，Spring 中为 Bean 中的方法，实际上 AOP 还可以拦截字段、构造器
- 切入点（Poincut）：指定何时使用对目标类进行应用通知，就是一个匹配连接点的断言或表达式，类似：
```java
@Pointcut("execution(* com.spring.two.UserMangeImpl.*(..))")
```

- 通知（Advice）：拦截到连接点的方法执行前后要执行的东西叫做通知，分为五种：前置、后置、环绕、异常、最终通知
- 切面（Aspect）：切面 = 通知 + 切点
- 织入：将切面类应用到被代理的 Bean 方法叫做织入

<a name="o69gE"></a>
### 6.3 Aop 中 Advice 的执行顺序

around > before > around > after > afterReturning

<a name="Xz1Tn"></a>
### 6.4 @AspectJ

基于字节码操作(Bytecode Manipulation)，通过编织阶段(Weaving Phase)，对目标Java类型的字节码进行操作，将需要的 Advice 逻辑给编织进去，形成新的字节码

- AspectJ 是静态代理的增强，所谓的静态代理就是 AOP 框架会在编译阶段生成 AOP 代理类，因此也称为编译时增强
- 编织阶段可以有两个选择，分别是：加载时编织(也可以成为运行时编织)、编译时编织

<a name="iatZN"></a>
### 6.5 Ioc 的几种注入方式

- 构造器注入：
```java
YoungMan(BeautifulGirl beautifulGirl){
        this.beautifulGirl = beautifulGirl;
}
```

- setter 注入：
```java
public class YoungMan {
  private BeautifulGirl beautifulGirl;

  public void setBeautifulGirl(BeautifulGirl beautifulGirl) {
      this.beautifulGirl = beautifulGirl;
  }
}
```

- 接口注入：不提倡

<a name="JySFJ"></a>
### 6.6 Spring Ioc 容器接口

- BeanFactory：低级容器，就是一个 HashMap，每一个注入对象都有一个 BeanDefinition（由 XmlBeanDefinitionReader 读取生成）
- ApplicationContext：高级容器，由 BeanFactory 接口派生而来，因而提供 BeanFactory 所有的功能，额外提供资源的获取，支持多种消息（例如 JSP tag 的支持），对 BeanFactory 多了工具级别的支持

<a name="rCD49"></a>
### 6.7 Spring Bean 是如何加载的

- 在xml配置bean的信息
- 然后通过XmlBeanDefinitionReader读取xml配置将文件内容映射到相应的BeanDefinition
- 通过BeanFactory和BeanDefinitionRegistry的具体实现类进行Bean的注册与获取

<a name="Kf35F"></a>
### 6.8、Spring Bean的生命周期

创建实例 -> 初始化 -> 使用 -> 销毁

Spring 在初始化后 BeanFactory 实例化后，就加载 Bean 定义（xml配置、注解或 Java 配置文件）配置，依次生成每个类对应Bean的单例对象，然后填充对象属性，然后开始 Bean 对象初始化，此处用户可以通过 @PostConstruct、继承 InitializingBean 类或指定 init-method 的方法自定义自己的初始化方法

<a name="gPuSt"></a>
### 6.9 Spring 框架的基础模块有哪些

- Core 模块：Spring 的核心工具类
- Beans 模块：是所有应用都要用到的，它包含访问配置文件、创建和管理 bean 以及 ioc、依赖注入
- Context 模块：构建于Core和Beans之上，是 Spring 的上下文环境，为 Spring 核心提供了大量的扩展，对国际化、事件传播、资源加载等支持，ApplicationContext 接口是 Context 模块的关键
- SpEL 模块：提供了一个强大的表达式语言用于在运行时查询并操纵对象

<a name="Arp0e"></a>
### 6.10、Bean的创建调用代码示例

```java
<bean id="hello" class="bean.HelloSpring" lazy-init="false"></bean>
...
public static void main(String[] args) {
    // spring 如何初始化有两种方式 beanFactory applicationContext
    Resource resource = new ClassPathResource("spring/ioc/beans.xml");
    BeanFactory beanFactory = new XmlBeanFactory(resource);
    HelloSpring helloSpring = (HelloSpring) beanFactory.getBean("hello");
    helloSpring.sayHello("张三");
}
```

<a name="2288455d"></a>
## 7 Jvm 面试

<a name="lNmd8"></a>
### 7.1 Java 源码的编译过程

- 词法分析器、语法分析器、语义分析器、字节码生成器 -> 生成 jvm 字节码

<a name="SHHSX"></a>
### 7.2 泛型擦除

是指泛型只会存在于 Java 源码中，编译后就会被替换成原生类型

<a name="ABjwp"></a>
### 7.3 Java 默认的三种加载器

- 启动类加载器
- 拓展类加载器
- 应用类加载器

<a name="Gdcvd"></a>
### 7.4 类的加载过程

- 加载：加载类的二进制数据，在内存中创建一个 Class 对象
- 连接：验证（文件格式、字节码等验证）-> 准备（为静态变量分配内存及默认初始值）-> 初始化（将类中的符号引用转换为直接引用）
- 初始化：为静态变量正确初始化值

<a name="WKrLA"></a>
### 7.5 Jvm 的内存模型（运行时数据区）

- 堆：存放对象实例
- 虚拟机栈：存放局部变量等
- 本地方法栈：本地方法栈则是为虚拟机使用到的 Native 方法服务
- 方法区：存储已被虚拟机加载的类的元数据信息
- 程序计数器：当前线程所执行字节码的行号指示器

<a name="9x4FY"></a>
### 7.6 Gc 是如何判断对象死去的

- 引用计数器 -> 为每个对象创建一个引用计数，有对象引用时计数器 +1，引用被释放时计数 -1，当计数器为 0 时就可以被回收（难以解决对象间的循环引用问题）
- 可达性分析算法 -> 从 GC Roots 开始向下搜索，搜索所走过的路径称为引用链。当一个对象到 GC Roots 没有任何引用链相连时，则证明此对象是可以被回收的（主流得到Jvm采取这种方式）

<a name="Wq9tf"></a>
### 7.7 Gc 垃圾回收算法

- 标记-清除算法：标记无用对象，然后进行清除回收
- 复制算法
- 标记-整理算法
- 分代收集算法

<a name="99STZ"></a>
### 7.8 内存泄漏

- 对象没有被使用
- 对象一直被引用无法释放

<a name="Nizw1"></a>
### 7.9 内存溢出 OOM

- 内存泄漏导致堆栈内存不断增大，最终导致内存溢出
- 操作大量的对象导致堆内存用尽，内存溢出
- 加载大量的 jar、class 文件，装载类的空间不够，内存溢出

<a name="qQwTT"></a>
### 7.10 Jvm 的主要组成

- 类加载器（ClassLoader）：把 Java 代码转换成字节码
- 运行时数据区（Runtime Data Area）：把字节码加载到内存中
- 执行引擎（Execution Engine）：将字节码翻译成底层系统指令，再交由 CPU 去执行
- 本地库接口（Native Interface）：和其它语言打交道的底层接口

<a name="hFqqe"></a>
### 7.11 堆栈的区别

- 功能方面：堆是用来存放对象的，栈是用来执行程序的
- 共享性：堆是线程共享，栈是线程私有的
- 空间大小：堆的大小远远大于栈

<a name="91643560"></a>
## 8 Mysql 面试

<a name="AH1WC"></a>
### 8.1 数据库的 ACID

- Atomicity（原子性）：一个事务（transaction）中的所有操作，或者全部完成，或者全部不完成，不会结束在中间某个环节
- Consistency（一致性）：在事务开始之前和事务结束以后，数据库的完整性没有被破坏
- Isolation（隔离性）：数据库允许多个并发事务同时对其数据进行读写和修改的能力，隔离性可以防止多个事务并发执行时由于交叉执行而导致数据的不一致
- Durability（持久性）：事务处理结束后，对数据的修改就是永久的，即便系统故障也不会丢失

<a name="EJ1h8"></a>
### 8.2 数据库的事务隔离

- READ-UNCOMMITTED：未提交读，最低隔离级别、事务未提交前，就可被其他事务读取（会出现幻读、脏读、不可重复读）
- READ-COMMITTED：提交读，一个事务提交后才能被其他事务读取到（会造成幻读、不可重复读）
- REPEATABLE-READ：可重复读，默认级别，保证多次读取同一个数据时，其值都和事务开始时候的内容是一致，禁止读取到别的事务未提交的数据（会造成幻读）
- SERIALIZABLE：序列化，代价最高最可靠的隔离级别，该隔离级别能防止脏读、不可重复读、幻读

<a name="ObLMR"></a>
### 8.3 如何做 MySQL 的性能优化

- 为搜索字段创建索引
- 避免使用 select *
- 垂直分割分表
- 选用正确的存储引擎

<a name="yMoVw"></a>
### 8.4 如何排查 mysql 问题

- explain 语句查看 sql 执行计划
- show processlist 命令查看当前所有连接信息
- 开启慢查询日志，查看慢查询的 SQL

<a name="G6Qq1"></a>
### 8.5 Mysql 索引类型

- FULLTEXT：全文索引，只有 MyISAM 引擎支持
- BTREE：一种将索引值按一定的算法，存入一个树形的数据结构中（多路平衡查找树），每次查询都是从树的入口 root 开始，依次遍历 node，获取 leaf。这是 MySQL 里默认和最常用的索引类型
- RTREE：仅支持 geometry 数据类型

<a name="VRAdW"></a>
### 8.6 Mysql 索引种类

- 唯一索引
- 主键索引
- 组合索引
- 全文索引
- 普通索引

```sql
--创建普通索引      CREATE INDEX index_name ON table_name(col_name);
--创建唯一索引      CREATE UNIQUE INDEX index_name ON table_name(col_name);
--创建普通组合索引  CREATE INDEX index_name ON table_name(col_name_1,col_name_2);
--创建唯一组合索引  CREATE UNIQUE INDEX index_name ON table_name(col_name_1,col_name_2);
```

<a name="Ybghw"></a>
### 8.7 Sql 调优的几种手段

- 创建索引
- 避免在索引上使用计算
- sql 预编译
- 使用表的别名加快 sql 解析时间
- 避免使用 select *，
- 应尽量避免在 where 子句中对字段进行 null 值判断，否则将导致引擎放弃使用索引而进行全表扫描
- 能用 between 就不要用 in
- 字段设置默认值
- 尽量避免使用游标，因为游标的效率较差
- 少用子查询
- 不要有超过 5 个以上的表连接（JOIN）
- 使用存储过程封装那些复杂的SQL语句或商业逻辑
  - 存储过程的执行计划可以被缓存在内存中较长时间，减少了重新编译的时间
  - 存储过程减少了客户端和服务器的繁复交互
  - 如果程序发布后需要做某些改变你可以直接修改存储过程而不用修改程序，避免需要重新安装部署程序

## 8 Kafka

<a name="dJZMe"></a>
### 8.1 基本概念

- Broker：可以简单理解为一个 Kafka 节点, 多个 Broker 节点构成整个 Kafka 集群
- Topic：某种类型消息的集合
- Partition：Topic 在物理上的分组，多个 Partition 分散存储在各个Broker上，单个 Partition 保证有序，多个不一定有序
- Segment：消息片段，包好一个 .index 和一个 .log 文件，一个 Partition 由多个 Segment 组成
- Replica：Partition 的冗余备份，一般每个 Partition 都会有 N 个完全相同的备份，这些备份分散在不同的 Broker 上

Producer 通过 Broker 向 Topic 发送消息；Consumer 通过 Broker 消费 Topic 的消息

<a name="EAZpr"></a>
### 8.2 Kafka 特点

- 高吞吐率
- 持久化数据存储
- 分布式系统易于扩展
- 客户端状态维护：消息被处理的状态是在 consumer 端维护，而不是由 server 端维护。减轻服务器端的压力，为客户端会话管理提供了更好的灵活性

<a name="QTJOB"></a>
### 8.3 Kafka 消费数据的模式

- 发布订阅模式：多个 Consumer 可以同时读取同一 Topic 的相同数据，使用不同的组区分 Consumer 即可
- 队列模式：多个 Consumer 位于同一消费者组，交替消费消息

<a name="WTzZV"></a>
### 8.4 发送数据流程

- 生产者根据制定的 partition 方法（round-robin，hash），将消息发布到制定 topic 的 partition 中
- kafka 集群接收到 Producer 发过来的消息后，将其持久化到硬盘，并保留消息指定时长（可配置），而不关注消息是否被消费
- Consumer 从 kafka 中 pull 数据，并控制获取消息的 offset

<a name="z7hke"></a>
### 8.5 Kafka 和 RabbitMQ 的区别

- 架构方面不同：RabbitMQ 遵循 AMQP 协议，kafka 遵从一般的 MQ 结构，producer，broker，consumer，以 consumer 为中心
- 应用场景不同：RabbitMQ，循 AMQP 协议，用于实时的对可靠性要求比较高的消息传递上；kafka 主要用于处理活跃的流式数据,大数据量的数据处理上
- 吞吐量：rabbitMQ 在吞吐量方面稍逊于 kafka，他们的出发点不一样，rabbitMQ 支持对消息的可靠的传递，支持事务、发送方确认，不支持批量的操作
<a name="4dxoe"></a>
### 8.6 Kafka 生产者生产数据的可靠性

生产者向 leader 发送数据时，可以选择需要的可靠性级别：通过 request.required.acks 参数设置（0：至多一次，1：至少一次，-1：刚好一次）

- 0：至多一次，生产者不停向 leader 发送数据，而不需要 leader 反馈成功消息，这种模式效率最高，可靠性最低，可能在发送过程中丢失数据
- -1：刚好一次
- 1：至少一次，producer 在 ISR 中的 leader 已成功收到数据并得到确认后才会发送下一条数据，如果等待响应超时，生产者自动重发数据

<a name="RabbitMq"></a>
## 9 RabbitMq

<a name="DKjRq"></a>
### 9.1 消息如何持久化

- 消息投递时设置消息持久化：channel.queueDeclare(x, true, false, false, null)，参数 2 设置 为 true 持久化
- 设置投递模式 deliveryMode 设置为 2（持久）：channel.basicPublish(x, x, MessageProperties.PERSISTENTTEXTPLAIN,x)，参数3设置为存储纯文本到磁盘
- 交换器持久化
- 队列持久化

<a name="T8Y0Y"></a>
### 9.2 什么是 vhost

vhost 是 mini 版的 RabbitMq 服务器，拥有自己的队列、交换器、权限

<a name="ifzBb"></a>
### 9.3 工作模式

- direct：直连模式，用于实例间的任务分发
- topic：话题模式，可自由配置分发规则
- headers：适用规则复杂的分发，用 headers 里的参数表达规则
- fanout：发布订阅模式，分发给所有绑定到该交换器的队列，直接忽略 RoutingKey

<a name="uAsF4"></a>
### 9.4 Rabbitmq 接收消息的两种模式

- 持续消息获取使用：basic.consume
- 单个消息获取使用：basic.get

<a name="0khtz"></a>
### 9.5 RoutingKey

RoutingKey 不能超过 255 个字节，使用 . 号作为分隔符

- *：配置一个分段（被.号分割）的内容
- #：匹配 0 个或多个字符

比如：BindingKey：com.mq.rabbit.error，匹配如下 RoutingKey：

- com.mq.rabbit.*
- com.mq.rabbit.#
- #.error
- com.mq.#

<a name="MoZlS"></a>
### 9.6 RabbitMq 的事务

解决问题：生产者发送消息到 Broker 之前发生意外，也就说如何确保消息准确投送到 Broker

- channel.txSelect()：声明启动事务模式
- channel.txComment()：提交事务
- channel.txRollback()：回滚事务

<a name="fZOHw"></a>
### 9.7 Confirm 发送方确认模式

- channel.confirmSelect()：开启发送方确认模式
- channel.waitForConfirms()：普通发送方确认模式
- channel.waitForConfirmsOrDie()：批量确认模式
- channel.addConfirmListener()：异步监听发送方确认模式

<a name="Redis"></a>
## 10 Redis

<a name="avYrr"></a>
### 10.1 Redis 使用场景

- 留言、点赞、评论、短信验证码、API 缓存等
- 缓存近期热帖
- 缓存文章详情
- session 共享

<a name="yXjD5"></a>
### 10.2 基本数据类型

Redis 支持的数据类型：string（字符串）、list（列表）、hash（字典）、set（集合）、zset（有序集合）

- string：INCR/DECR/INCRBY/DECRBY/GET/SETAPPEND/SUBSTR
- list：RPUSH/LPUSH/RPOP/LPOP/LRANGE/LTRIM
- set：SADD/SREM/SISMEMBER/SPOP/SMOVE/SCARD/SDIFF/SUNION/SINTER
- hash：HMGET/HMSET/HDEL/HLEN/HKEYS/HEXISTS/HGETALL/HINCRBY
- zset：ZADD/ZREM/ACARD/ZCOUNT/ZRANGEZINCRBY

<a name="GUWis"></a>
### 10.3 Redis 为什么是单线程的

Redis 的瓶颈最有可能是机器内存或者网络带宽。既然单线程容易实现，而且 cpu 又不会成为瓶颈，那就顺理成章地采用单线程的方案了

<a name="uzDWT"></a>
### 10.4 如何保证缓存和数据库数据的一致性

- 合理设置缓存过期时间
- 新增、修改、删除等操作也要同步更新Redis，可以使用事务机制保证数据一致性

<a name="AGfmu"></a>
### 10.5 Redis 的持久化方式

- RDB（Redis Database）：定时对 Redis 全量数据进行快照存储
- AOF（Append Only File）：每一个收到的写命令都通过 write 函数追加到文件中

<a name="P6Ssk"></a>
### 10.6 Redis 如何实现分布式锁

分布式锁其实就是程序“占坑”，Redis 使用 setnx（set if not exists）实现，只允许被一个程序占有，使用完调用 del 释放锁

<a name="6bkpx"></a>
### 10.7 Redis 常见的性能问题

- 主服务器写内存快照，会阻塞主线程的工作，当快照比较大时对性能影响是非常大的，会间断性暂停服务，所以主服务器最好不要写内存快照
- Redis 主从复制的性能问题，为了主从复制的速度和连接的稳定性，主从库最好在同一个局域网内

<a name="XLCCx"></a>
### 10.8 Redis 事务

Redis 事务以 multi() 开头，最后以 exec() 结束，中间执行各种 Redis 命令

## 11 Tcp Ip网络协议相关

### 11.1 Tcp 连接的三次握手

- 客户端发送 syn 包到服务器
- 服务器收到客户端的 syn 包，回执一个 syn 包，服务器进入待连接状态
- 客户端收到服务器的 syn 包后再次发送 ack 包

