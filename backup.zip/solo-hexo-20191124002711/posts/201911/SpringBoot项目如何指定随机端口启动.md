title: Spring Boot 项目如何指定随机端口启动
date: '2019-11-04 23:50:40'
updated: '2019-11-05 16:52:58'
tags: [SpringBoot, Java]
permalink: /articles/2019/11/04/1572882640366.html
---
![](https://img.hacpai.com/bing/20180208.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 1 什么是随机端口
首先，什么是随机端口？在我们平常的 Spring Boot 开发中，项目启动端口一般会直接写入 **application.yml** 文件中，比如如下方式指定启动端口为 **8082**：
```
server:
  port: 8082
```
项目启动后，首先会监听 **8082** 端口，如果端口冲突的话，项目是启动不起来的，哦，mygod😰 ，这个时候你才会发现使用随机端口启动的重要性。这样写的弊端笔者总结了下：

-  端口冲突，项目启动不起来，需要修改端口重试
- 微服务场景下，服务调用都是使用服务名进行，端口是可以对调用者透明地

当然，使用随机端口，一大好处就是很方便的应对服务得到扩容，特别是微服务场景下，想象一下，假设服务个数达到几十个，这样势必每个服务都会有一个端口，倘若本地需要全部启动这些服务的话（当然，一般各个服务可能会分开部署，不会都部署在同一台机器），那么很有可能会导致端口冲突。

为应对大规模服务自动扩容而端口不会冲突的场景，使用随机端口就可以轻松解决该问题，实际上，做过 VueJs 的同学想必都知道 VueJs项目启动时就是使用的随机端口，防止本地端口冲突。

使用随机端口启动的话流程图大概如下：

![image.png](https://img.hacpai.com/file/2019/11/image-368a52cd.png)

## 2 如何判断端口是否占用
判断端口占用其实十分简单，我们一般在 Windows 或者 Linux 编程时判断项目是否启动采用的什么办法？没错，就是 telnet 或者 ping，Java 判断端口是否占用一样的道理，我们只需要用 Java Socket 去连接该端口，倘若连接成功没有异常，说明端口在使用，连接失败就说明该端口可用是闲置端口。来看下基础代码吧：
```java
package com.codeshop.spring.cloud.util;

import java.net.Socket;

public class NetUtil {
    // 判断本地端口是否可用
    public static boolean isLocalPortUsing(int port) {
        try {
            new Socket("127.0.0.1", port).close();
            // socket连接正常，说明该端口占用
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

```
代码都比较简单，我们提供一个 NetUtil 工具类来判断端口是否可用。那么，端口是如何遍历的呢，我们知道端口的范围是不大于 65535 的，我们采取随机递归遍历方式，直到找到有效端口为止：
```java
package com.codeshop.spring.cloud.util;

import java.util.Random;

public class ServerPortUtil {
    /**
     * 获取闲置端口，采用随机递归方式
     * @return
     */
    public static int getAvailablePort() {
        int max = 65535;
        int min = 2000;
        Random random = new Random();
        int port = random.nextInt(max) % (max - min + 1) + min;
        // 判断端口是否可用
        boolean isLocalPortUsing = NetUtil.isLocalPortUsing(port);
        if (isLocalPortUsing) {
            // 端口占用，继续遍历
            return getAvailablePort();
        } else {
            // 端口没有占用，返回有效端口
            return port;
        }
    }
}

```
看到了吧，是不恍然大悟，哈哈，小心心走起来❤️ ~
## 3 如何用代码指定 Spring Boot 启动端口
大家都知道，Spring Boot 项目启动的时候是什么样子的呢？如下：
```java
@SpringBootApplication
public class SpringCloudStarterApplication {

    public static void main(String[] args) {
        new StartCommand(args);
        SpringApplication.run(SpringCloudStarterApplication.class, args);
    }

}
```
可以看到，启动方法也就是 main 方法有个参数 args，其实，我们只需要从 args 里面去判断是否指定了启动端口，如果没有指定的话，我们再去获取并设置一个随机有效端口。关键代码来了，来了，别眨眼，瞅仔细哈：
```java
System.setProperty("server.port", String.valueOf(port));
```
使用以上 API 可以设置一个系统属性即有效端口，然后配置 **application.yml：** 去动态获取该有效端口即可：
```yml
server:
  port: ${server.port} # 应用端口
```
是不是很简单呢？一起看看我们的 **StartCommand** 类是怎么实现这个逻辑的？
```java
package com.codeshop.spring.cloud.util;

import org.springframework.util.StringUtils;

public class StartCommand {
    public StartCommand(String[] args) {
        boolean isServerPort = false;
        String serverPort = "";
        if (args != null) {
            for (String arg: args) {
                if (StringUtils.hasText(arg) && arg.startsWith("--server.port")) {
                    isServerPort = true;
                    serverPort = arg;
                    break;
                }
            }
        }
        // 如果没有指定端口
        if (!isServerPort) {
            int port = ServerPortUtil.getAvailablePort();
            System.setProperty("server.port", String.valueOf(port));
        } else {
            System.setProperty("server.port", serverPort.split("=")[1]);
        }
    }

}

```
其实主要逻辑我上面已经介绍过了，不再赘述，然后启动类 main 方法加入关键代码：
```java
public static void main(String[] args) {
        new StartCommand(args); // 👍 这是重点，画个圈圈起来👍 
        SpringApplication.run(SpringCloudStarterApplication.class, args);
    }
```
完事后，启动项目，就会发现启动端口是随机的了，是不一下感觉舒服很多，麻麻再也不用为我的端口冲突而烦恼了~❤️ 

